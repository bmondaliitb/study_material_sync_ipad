/*
 * MyMuon.cpp
 *
 *  Created on: Feb 1, 2012
 *      Author: csander
 */

#include "MyMuon.h"

MyMuon::MyMuon() {
   // TODO Auto-generated constructor stub
}

MyMuon::~MyMuon() {
   // TODO Auto-generated destructor stub
}
