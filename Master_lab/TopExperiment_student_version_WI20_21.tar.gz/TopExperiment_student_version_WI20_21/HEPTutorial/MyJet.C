/*
 * MyJet.cpp
 *
 *  Created on: Feb 1, 2012
 *      Author: csander
 */

#include "MyJet.h"

MyJet::MyJet() {
   // TODO Auto-generated constructor stub
}

MyJet::~MyJet() {
   // TODO Auto-generated destructor stub
}
